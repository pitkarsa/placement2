package com.niit.placement.model;

public class JD {

	private int jdID,salary;
	private String compName,compLocation,req1,req2,req3,contactPerson,contactNumber,contactEmail,role;
	
	@Override
	public String toString() {
		return "JD [jdID=" + jdID + ", salary=" + salary + ", compName=" + compName + ", compLocation=" + compLocation
				+ ", req1=" + req1 + ", req2=" + req2 + ", req3=" + req3 + ", contactPerson=" + contactPerson
				+ ", contactNumber=" + contactNumber + ", contactEmail=" + contactEmail + ", role=" + role + "]";
	}
	public int getJdID() {
		return jdID;
	}
	public void setJdID(int jdID) {
		this.jdID = jdID;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public String getCompLocation() {
		return compLocation;
	}
	public void setCompLocation(String compLocation) {
		this.compLocation = compLocation;
	}
	public String getReq1() {
		return req1;
	}
	public void setReq1(String req1) {
		this.req1 = req1;
	}
	public String getReq2() {
		return req2;
	}
	public void setReq2(String req2) {
		this.req2 = req2;
	}
	public String getReq3() {
		return req3;
	}
	public void setReq3(String req3) {
		this.req3 = req3;
	}
	public String getContactPerson() {
		return contactPerson;
	}
	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getContactEmail() {
		return contactEmail;
	}
	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	
}
