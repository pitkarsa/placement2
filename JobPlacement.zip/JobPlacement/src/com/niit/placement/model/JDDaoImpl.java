package com.niit.placement.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.niit.placement.dao.JDDao;
import com.niit.placement.utility.DBUtility;

public class JDDaoImpl implements JDDao {

	@Override
	public boolean addJD(JD jd) {
		
		String sql="insert into JD(compName,compLocation,req1,req2,req3,contactPerson,contactNumber,contactEmail,jobrole,salary) values(?,?,?,?,?,?,?,?,?,?)";
		Connection con=DBUtility.getCon();
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, jd.getCompName());
			ps.setString(2, jd.getCompLocation());
			ps.setString(3, jd.getReq1());
			ps.setString(4, jd.getReq2());
			ps.setString(5, jd.getReq3());
			ps.setString(6, jd.getContactPerson());
			ps.setString(7, jd.getContactNumber());
			ps.setString(8, jd.getContactEmail());
			ps.setString(9, jd.getRole());
			ps.setInt(10, jd.getSalary());
			int rows=ps.executeUpdate();
			if(rows>0) return true;
			else return false;
			
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
		
	}

}
