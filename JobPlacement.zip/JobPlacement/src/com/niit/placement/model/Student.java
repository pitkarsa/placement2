package com.niit.placement.model;

public class Student {

}
