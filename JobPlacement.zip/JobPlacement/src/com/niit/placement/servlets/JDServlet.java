package com.niit.placement.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.niit.placement.dao.JDDao;
import com.niit.placement.model.JD;
import com.niit.placement.model.JDDaoImpl;

/**
 * Servlet implementation class JDServlet
 */
@WebServlet("/JDServlet")
public class JDServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public JDServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		JDDao dao=new JDDaoImpl();
		
		JD jd=new JD();
		jd.setCompLocation(request.getParameter("compLocation"));
		jd.setCompName(request.getParameter("compName"));
		jd.setContactEmail(request.getParameter("contactEmail"));
		jd.setContactNumber(request.getParameter("contactNumber"));
		jd.setContactPerson(request.getParameter("contactPerson"));
		jd.setReq1(request.getParameter("req1"));
		jd.setReq2(request.getParameter("req2"));
		jd.setReq3(request.getParameter("req3"));
		jd.setRole(request.getParameter("role"));
		jd.setSalary(Integer.parseInt(request.getParameter("salary")));
		
		if(dao.addJD(jd))
			response.sendRedirect("added!!!");
		else
			response.sendRedirect("Error!!!");
		
		
		
		
		
		
		
	}

}
