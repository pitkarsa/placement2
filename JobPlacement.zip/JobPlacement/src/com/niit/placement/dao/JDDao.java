package com.niit.placement.dao;

import com.niit.placement.model.JD;

public interface JDDao {

	boolean addJD(JD jd);
	
}
