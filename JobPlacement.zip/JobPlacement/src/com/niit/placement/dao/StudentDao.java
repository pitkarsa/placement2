package com.niit.placement.dao;

public interface StudentDao {

}
