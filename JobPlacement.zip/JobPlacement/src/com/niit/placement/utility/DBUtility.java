package com.niit.placement.utility;

import java.util.*;
import java.sql.*;

public class DBUtility {
	static public Connection getCon() {
		Connection con;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/techConference","root","addy2012");
			return con;
		}
		catch(SQLException | ClassNotFoundException e)
		{
			e.printStackTrace();
			return null;
		}
		
	}
}
